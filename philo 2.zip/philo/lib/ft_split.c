/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/03 18:13:07 by rlahmaid          #+#    #+#             */
/*   Updated: 2019/11/06 16:32:02 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static size_t	ft_words(char const *s, char c)
{
	size_t	i;
	size_t	count;
	int		m;

	i = 0;
	m = 0;
	count = 0;
	while (s[i])
	{
		if (s[i] == c)
			m = 0;
		else if (m == 0)
		{
			m = 1;
			count++;
		}
		i++;
	}
	return (count);
}

static size_t	ft_allocate(char *s, char c)
{
	int count;

	count = 0;
	while (*s != c && *s)
	{
		s++;
		count++;
	}
	return (count + 1);
}

static char		**ft_split1(char *s, char c, char **p, size_t count)
{
	size_t	i;
	int		j;
	int		k;

	i = 0;
	while (*s && i < count)
	{
		j = 0;
		while (*s == c)
			s++;
		if (!(p[i] = (char *)malloc(ft_allocate(s, c) * sizeof(char))))
		{
			k = i;
			while (k)
				free(p[k--]);
			free(p);
			return (0);
		}
		while (*s != c && *s)
			p[i][j++] = *s++;
		p[i++][j] = '\0';
	}
	p[i] = 0;
	return (p);
}

char			**ft_split(char const *s, char c)
{
	char	*str;
	char	**p;

	if (!s)
		return (0);
	str = (char *)s;
	if (!(p = (char **)malloc((ft_words(str, c) + 1) * sizeof(char *))))
		return (0);
	return (ft_split1(str, c, p, ft_words(str, c)));
}
