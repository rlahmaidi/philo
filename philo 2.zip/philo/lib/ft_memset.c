/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/11 16:18:49 by rlahmaid          #+#    #+#             */
/*   Updated: 2019/11/07 01:56:05 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memset(void *b, int c, size_t len)
{
	unsigned char *ptr;
	unsigned char d;

	ptr = (unsigned char *)b;
	d = (unsigned char)c;
	while (len-- > 0)
	{
		*ptr = d;
		ptr++;
	}
	return (b);
}
