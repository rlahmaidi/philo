/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/22 01:39:38 by rlahmaid          #+#    #+#             */
/*   Updated: 2019/11/05 16:51:32 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	char			*substr;
	unsigned int	i;
	unsigned int	j;

	i = 0;
	j = 0;
	if (!s)
		return (NULL);
	if (!(substr = (char *)malloc(len + 1)))
		return (NULL);
	if (start > ft_strlen((char *)s))
		return (substr = ft_strdup(""));
	while (i < start)
		i++;
	while (*(s + i) && len > 0)
	{
		*(substr + j) = *(s + i);
		j++;
		i++;
		len--;
	}
	*(substr + j) = '\0';
	return (substr);
}
