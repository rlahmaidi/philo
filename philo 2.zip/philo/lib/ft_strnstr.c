/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/30 17:24:42 by rlahmaid          #+#    #+#             */
/*   Updated: 2019/11/11 20:39:35 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *dst, const char *src, size_t len)
{
	char	*i;
	char	*k;
	size_t	cp;

	if (!(src[0]))
		return ((char *)dst);
	while (*dst && len)
	{
		if (*dst == src[0])
		{
			cp = len;
			i = (char *)dst;
			k = (char *)src;
			while (*i == *k && cp-- && *k && *i)
			{
				++i;
				++k;
			}
			if (!*k)
				return ((char *)dst);
		}
		++dst;
		--len;
	}
	return (NULL);
}
