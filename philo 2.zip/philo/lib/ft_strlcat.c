/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/23 03:52:46 by rlahmaid          #+#    #+#             */
/*   Updated: 2019/11/09 00:26:04 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t		ft_strlcat(char *dst, const char *src, size_t l)
{
	size_t	l1;
	size_t	l2;
	size_t	k;

	k = 0;
	l2 = ft_strlen(src);
	if (l == 0)
		return (l2);
	l1 = ft_strlen(dst);
	if (l <= l1)
		return (l + l2);
	while (k < l - l1 - 1 && src[k] != '\0')
	{
		dst[k + l1] = src[k];
		k++;
	}
	dst[k + l1] = '\0';
	return (l1 + l2);
}
