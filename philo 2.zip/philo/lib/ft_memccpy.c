/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memccpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/20 00:50:21 by rlahmaid          #+#    #+#             */
/*   Updated: 2019/11/07 01:53:26 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memccpy(void *dst, const void *src, int c, size_t n)
{
	unsigned char	*dest;
	unsigned char	*sorc;
	size_t			i;
	unsigned char	t;

	dest = (unsigned char *)dst;
	sorc = (unsigned char *)src;
	t = (unsigned char)c;
	i = 0;
	while (i < n)
	{
		*(dest + i) = *(sorc + i);
		if (*(sorc + i) == t)
			return (dst + i + 1);
		i++;
	}
	return (NULL);
}
