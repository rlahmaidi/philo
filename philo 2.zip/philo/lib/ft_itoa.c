/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/23 02:02:53 by rlahmaid          #+#    #+#             */
/*   Updated: 2019/11/06 16:30:18 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int		len(unsigned int i)
{
	int				len;

	len = 0;
	while (i > 0)
	{
		len++;
		i = i / 10;
	}
	return (len);
}

char			*ft_itoa(int n)
{
	char			*str;
	unsigned int	nb;
	int				l;

	l = 0;
	nb = n;
	if (n <= 0)
	{
		nb = n * (-1);
		l = 1;
	}
	l += len(nb);
	if (!(str = (char *)malloc((l + 1) * sizeof(char))))
		return (0);
	*(str + l) = '\0';
	while (l--)
	{
		*(str + l) = nb % 10 + '0';
		nb = nb / 10;
	}
	if (n < 0)
		*str = '-';
	return (str);
}
