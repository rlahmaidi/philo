/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/22 00:37:51 by rlahmaid          #+#    #+#             */
/*   Updated: 2019/11/06 16:31:13 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static size_t		ft_len(char *s)
{
	size_t		len;

	len = 0;
	while (*s)
	{
		len++;
		s++;
	}
	return (len);
}

char				*ft_strjoin(char const *s1, char const *s2)
{
	size_t		i;
	char		*s;

	i = 0;
	if (!s1)
		return (NULL);
	if (!(s = (char *)malloc((ft_len((char *)s1) + ft_len((char *)s2) + 1))))
		return (NULL);
	i = 0;
	while (*s1)
	{
		*(s + i) = *s1;
		i++;
		s1++;
	}
	while (*s2)
	{
		*(s + i) = *s2;
		i++;
		s2++;
	}
	*(s + i) = '\0';
	return (s);
}
