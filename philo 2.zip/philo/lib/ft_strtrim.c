/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/22 02:50:39 by rlahmaid          #+#    #+#             */
/*   Updated: 2019/11/06 16:32:57 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static unsigned int	ft_start(char const *s1, char const *set)
{
	unsigned int	i;
	unsigned int	j;

	i = 0;
	while (*(s1 + i))
	{
		j = 0;
		while (*(set + j))
		{
			if (*(s1 + i) == *(set + j))
				break ;
			j++;
		}
		if (*(set + j) == '\0')
			break ;
		i++;
	}
	return (i);
}

static unsigned int	ft_end(char const *s1, char const *set)
{
	unsigned int	k;
	unsigned int	j;

	k = 0;
	while (*(s1 + k))
		k++;
	k--;
	while (k > ft_start(s1, set))
	{
		j = 0;
		while (*(set + j))
		{
			if (*(set + j) == *(s1 + k))
				break ;
			j++;
		}
		if (*(set + j) == '\0')
			break ;
		k--;
	}
	return (k);
}

char				*ft_strtrim(char const *s1, char const *set)
{
	char	*s;

	if (!s1)
		return (NULL);
	if (*s1 == '\0')
		return ((char *)s1);
	if (s1 && !set)
		return ((char *)s1);
	if (!(s = (char *)malloc(ft_end(s1, set) - ft_start(s1, set) + 2)))
		return (NULL);
	s = ft_substr(s1, ft_start(s1, set)
			, ft_end(s1, set) - ft_start(s1, set) + 1);
	return ((char *)s);
}
