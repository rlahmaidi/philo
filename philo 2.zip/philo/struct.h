#ifndef STRUCT_H
#define STRUCT_H

# include <stdio.h>
# include <stdlib.h>
# include <pthread.h>
# include <unistd.h>
# include <sys/time.h>
#include <pthread.h>

typedef struct s_arg
{
    int number_philo;
    size_t time_to_die;
    size_t time_to_eat;
    size_t time_to_sleep;
    int number_of_times_to_eat;
}           t_arg;

typedef struct s_philo
{
    int         id;
    int         left_fork;
    int         right_fork;
    int         meals_number;
    int         last_meal;

}              t_philo;

typedef struct s_table
{
    t_arg                       *arguments;
    pthread_mutex_t            *forks;
    t_philo                     *philos;

}               t_table;

t_arg    *get_argument(int ac, char **av);
int		ft_atoi(const char *str);
int		ft_isdigit(int c);
t_philo     *init_philos(t_table *table);
pthread_mutex_t *init_forks(t_table *table);
void        create_threads(t_table **table);
double      ft_time(void);
#endif