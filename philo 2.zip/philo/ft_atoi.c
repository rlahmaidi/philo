/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <rlahmaid@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/12 23:20:25 by rlahmaid          #+#    #+#             */
/*   Updated: 2021/11/04 18:27:45 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "struct.h"

int		ft_atoi(const char *str)
{
	int		sign;
	size_t	a;

	sign = 1;
	a = 0;
	while ((*str >= 9 && *str <= 13) || *str == ' ')
		str++;
	if (*str == '-')
	{
		sign = -1;
		str++;
	}
	else if (*str == '+')
		str++;
	while (*str >= '0' && *str <= '9')
	{
		a = a * 10 + (*str) - '0';
		str++;
		if (a > 9223372036854775807 && sign == 1)
			return (-1);
		if (sign == -1 && a > 9223372036854775807)
			return (0);
	}
	return ((int)a * sign);
}
