#include "struct.h"
#include "utils.c"

double	ft_time(void)
{
	struct timeval	tv;
	double			time_in_milli;

	gettimeofday(&tv, NULL);
	time_in_milli = (tv.tv_sec) * 1000 + (tv.tv_usec) / 1000;
	return (time_in_milli);
}

int      check_syntax(char **av)
{
    int i;
    int j;

    i = 1;
    while (av[i])
    {
        j = 0;
        while (av[i][j] != '\0')
        {
            if (!ft_isdigit(av[i][j]))
                return (0);
            j++;
        }
        i++;
    }
    return (1);
}
//initialize general information
t_arg    *get_argument(int ac, char **av)
{
    t_arg *argument;

    argument = (t_arg *)malloc(sizeof(t_arg));
    if (!argument)
        return (NULL);
    if (!check_syntax(av))
    {
        printf("incorrect syntax\n");
        return (NULL);
    }
    argument->number_philo = ft_atoi(av[1]);
    argument->time_to_die = ft_atoi(av[2]);
    argument->time_to_eat = ft_atoi(av[3]);
    argument->time_to_sleep = ft_atoi(av[4]);
    if(ac == 6)
        argument->number_of_times_to_eat = ft_atoi(av[5]);
    else
        argument->number_of_times_to_eat =-1;
    return(argument);
}

// initialize philo information
t_philo     *init_philos(t_table *table)
{
    t_philo *philos;
    int     i;

    i = 0;
    philos = (t_philo *)malloc(sizeof(t_philo) * table->arguments->number_philo);
    if (!philos)
        return (NULL);
    while (i < table->arguments->number_philo)
    {
        philos[i].id = i + 1;
        philos[i].left_fork = i;
        philos[i].right_fork = (i + 1) % table->arguments->number_philo;
        philos[i].meals_number = 0;
        philos[i].last_meal = ft_time();
        i++;
    }
    return (philos);

}

// initialize forks as a mutex's
pthread_mutex_t *init_forks(t_table *table)
{
    int i;

    i = 0;
    table->forks = (pthread_mutex_t *)malloc(sizeof(pthread_mutex_t) * table->arguments->number_philo);
    if (!table->forks)
        return (NULL);
    while (i < table->arguments->number_philo)
    {
        pthread_mutex_init(table->forks + i, NULL);
        i++;
    }
    return (table->forks);
}
void    delay(size_t delay)
{
    size_t beginning;

    beginning = ft_time();
    while ((ft_time() - beginning) < delay)
        usleep(60);
}

void    *routine(void *arg)
{
   t_table *table;

   table = arg;
   while (1)
   {

       // eat
       // grab forks
       pthread_mutex_lock(&table->forks[table->philos->left_fork]);
       printf("[%d] has taken a fork \n", table->philos->id);
       pthread_mutex_lock(&table->forks[table->philos->right_fork]);
       printf("[%d] has taken a fork \n", table->philos->id);
       // start eating
       printf("[%d] is eating\n", table->philos->id);
       table->philos->last_meal = ft_time();
       delay(table->arguments->time_to_eat);
       table->philos->meals_number += 1;
       //realeaseforks
       pthread_mutex_unlock(&table->forks[table->philos->left_fork]);
       pthread_mutex_unlock(&table->forks[table->philos->right_fork]);
       
       
       
       
       // sleep
       printf("[%d] is sleeping\n", table->philos->id);
       delay(table->arguments->time_to_sleep);
       // think
       printf("[%d] is thinking\n", table->philos->id);
   }

}
/*pthread_t                   philo_thread[table->argument.number_philo]; */
// create threads that represents philos
void      create_threads(t_table **table)
{
    pthread_t                       *philo_thread;
    t_table *tmp;
    int i;

    philo_thread = (pthread_t *)malloc(sizeof(pthread_t) * table->arguments->number_philo);
    if (!philo_thread)
        return (NULL);
    i = 0;
    tmp = *table;
    while (i < tmp->arguments->number_philo)
    {
        pthread_create(&philo_thread + i, NULL, &routine, &tmp);
        i++;
    }
}