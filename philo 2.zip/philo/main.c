#include "struct.h"


int main(int ac, char **av)
{
    t_table *table;

    table = (t_table *)malloc(sizeof(t_table));
    if (ac == 5 || ac == 6)
    {
        table->arguments = get_argument(ac, av);
        if (!table->arguments)
            return (0);
        table->philos = init_philos(table);
        if (!table->philos)
            return (0);
        table->forks = init_forks(table);
        create_threads(&table);
        while(1);
        
    }
    else
    {
        printf("Bad args number\n");
        return (0);
    }
    return (0);
}