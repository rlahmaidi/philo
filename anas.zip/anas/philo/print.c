/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/23 12:11:16 by rlahmaid          #+#    #+#             */
/*   Updated: 2021/11/23 12:11:18 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void	print_msg(t_philo *philo, char *msg)
{
	pthread_mutex_lock (&(philo->table->print));
	ft_putnbr (ft_time() - philo->table->t0);
	write (1, " ", 1);
	ft_putnbr (philo->id);
	write (1, msg, ft_strlen (msg));
	pthread_mutex_unlock (&(philo->table->print));
}
