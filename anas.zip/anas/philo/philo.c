/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/23 09:26:12 by rlahmaid          #+#    #+#             */
/*   Updated: 2021/11/23 09:26:16 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void	delay(size_t delay)
{
	size_t	beginning;

	beginning = ft_time ();
	while ((ft_time() - beginning) < delay)
		usleep(60);
}

void	get_left_right(t_philo *philo, int *left, int *right)
{
	*left = philo->id - 1;
	*right = philo->id % philo->table->args->number_philo;
}

void	unlock(t_philo *philo, int left, int right)
{
	pthread_mutex_unlock (&(philo)->eating);
	pthread_mutex_unlock ((philo)->table->forks + left);
	pthread_mutex_unlock ((philo)->table->forks + right);
}

void	*routine(void *philo)
{
	int	left;
	int	right;

	if (((t_philo *)philo)->id % 2 == 0)
		usleep (200);
	while (1)
	{
		get_left_right ((t_philo *)philo, &left, &right);
		pthread_mutex_lock (((t_philo *)philo)->table->forks + left);
		print_msg (philo, TAKE_FORK);
		pthread_mutex_lock (((t_philo *)philo)->table->forks + right);
		print_msg (philo, TAKE_FORK);
		((t_philo *)philo)->is_eating = 1;
		pthread_mutex_lock (&((t_philo *)philo)->eating);
		print_msg (philo, EATING);
		((t_philo *)philo)->last_meal = ft_time ();
		delay (((t_philo *)philo)->table->args->time_to_eat);
		((t_philo *)philo)->is_eating = 0;
		((t_philo *)philo)->meals_number++;
		unlock(philo, left, right);
		print_msg (philo, SLEEPING);
		delay (((t_philo *)philo)->table->args->time_to_sleep);
		usleep(100);//should uncommented
		print_msg (philo, THINKING);
	}
}

void	create_threads(t_table *table)
{
	int	i;

	i = -1;
	while (++i < table->args->number_philo)
	{
		pthread_create \
		(&(table->philos[i].index), NULL, &routine, table->philos + i);
	}
}
