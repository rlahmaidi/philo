/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_and_args.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rlahmaid <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/23 12:10:17 by rlahmaid          #+#    #+#             */
/*   Updated: 2021/11/23 12:10:22 by rlahmaid         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

size_t	ft_time(void)
{
	struct timeval	tv;
	size_t			time_in_milli;

	gettimeofday(&tv, NULL);
	time_in_milli = (tv.tv_sec) * 1000 + (tv.tv_usec) / 1000;
	return (time_in_milli);
}

int	check_syntax(char **av)
{
	int	i;
	int	j;

	i = 1;
	while (av[i])
	{
		j = 0;
		while (av[i][j] != '\0')
		{
			if (!ft_isdigit(av[i][j]))
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

t_arg	*get_argument(int ac, char **av)
{
	t_arg	*argument;

	argument = (t_arg *)malloc(sizeof(t_arg));
	if (!argument)
		return (NULL);
	if (!check_syntax(av))
	{
		printf ("incorrect syntax\n");
		return (NULL);
	}
	argument->number_philo = ft_atoi (av[1]);
	if (argument->number_philo <= 0)
	{
		printf ("number of philos must be strict positive");
		return (NULL);
	}
	argument->time_to_die = ft_atoi (av[2]);
	argument->time_to_eat = ft_atoi (av[3]);
	argument->time_to_sleep = ft_atoi (av[4]);
	if (ac == 6)
		argument->number_meals = ft_atoi (av[5]);
	else
		argument->number_meals = -1;
	return (argument);
}

void	init_philos(t_table *table)
{
	int	i;

	table->philos = malloc (sizeof (t_philo) * table->args->number_philo);
	if (!table->philos)
		return ;
	i = 0;
	while (i < table->args->number_philo)
	{
		table->philos[i].id = i + 1;
		table->philos[i].meals_number = 0;
		table->philos[i].last_meal = ft_time ();
		pthread_mutex_init (&(table->philos[i].eating), NULL);
		table->philos[i].table = table;
		i++;
	}
}

void	init_forks(t_table *table)
{
	int	i;

	table->forks = \
	malloc (sizeof (pthread_mutex_t) * table->args->number_philo);
	if (!table->forks)
		return ;
	i = 0;
	while (i < table->args->number_philo)
	{
		pthread_mutex_init (table->forks + i, NULL);
		i++;
	}
}
