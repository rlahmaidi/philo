#inlcude <unistd.h>
#inlcude <pthread.h>
#inlude <stdio.h>

int primes[10] = {2, 3, 5, 7, 9 ,11, 13, 17, 19,29};
void *routine(void *index)
{
    printf("%d",primes[(int)index]);
}
int main()
{
    pthread_t th[10];
    
    int i;

    i = 0;
    while(i < 10)
    {
        pthread_create(th[i],NULL,&routine,&i);
        i++;
    }   
}