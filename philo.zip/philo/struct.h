typedef struct s_arg
{
   int number_of_philo
    int time_to_die;
    in time_to_eat;
    int time_to_sleep;
    int number_of_times_to_eat;
}           t_arg;

typedef struct s_threads
{
    pthread_t th;
    int thread_number
}              t_threads;

typedef 