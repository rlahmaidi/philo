#include "struct.h"
#include <pthread.h>

t_arg    get_argument(int ac, char **av)
{
    t_arg argument;

    if(ac < 4)
     //sumilation should stop somehow?
    argument.number_of_philo = ft_atoi(av[1]);
    argument.time_to_die = ft_atoi(av[2]);
    argument.time_to_eat = ft_atoi(av[3]);
    argument.time_to_sleep = ft_atoi(av[4]);
    if(av[5])
        argument.number_philo = ft_atoi(av[5]);
return(argument);
}

void create_threads(t_arg argument)
{
    int i;


    while(argument.number_of_philo > 0)
    {
        pthread_create();
    }
}

int main(int ac, char **av)
{
    t_arg argument;
    argument = get_arguments(int ac, char **av);
    create_threads();
}